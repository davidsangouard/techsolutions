<?php 
session_start();
require_once 'includes/config.php';
require_once 'includes/security.php';

$message = '';
$messageType = '';

if(isset($_POST['register'])) {
    try {
        // Validation et nettoyage
        $nom = clean_input($_POST['nom'] ?? '', 100);
        $prenom = clean_input($_POST['prenom'] ?? '', 100);
        $email = validate_email($_POST['email'] ?? '');
        $telephone = clean_input($_POST['telephone'] ?? '', 20);
        $entreprise = clean_input($_POST['entreprise'] ?? '', 200);
        $adresse = clean_input($_POST['adresse'] ?? '', 300);
        $ville = clean_input($_POST['ville'] ?? '', 100);
        $code_postal = clean_input($_POST['code_postal'] ?? '', 10);
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        // Validations
        if(strlen($nom) < 2) {
            throw new Exception("Le nom doit contenir au moins 2 caractères");
        }
        
        if(strlen($prenom) < 2) {
            throw new Exception("Le prénom doit contenir au moins 2 caractères");
        }
        
        if(!$email) {
            throw new Exception("Email invalide");
        }
        
        if(strlen($password) < 8) {
            throw new Exception("Le mot de passe doit contenir au moins 8 caractères");
        }
        
        if($password !== $confirm_password) {
            throw new Exception("Les mots de passe ne correspondent pas");
        }
        
        if(!isset($_POST['rgpd_consent'])) {
            throw new Exception("Vous devez accepter la politique de confidentialité");
        }
        
        // Vérifier si email existe
        $stmt = $pdo->prepare("SELECT id FROM clients WHERE email = ?");
        $stmt->execute([$email]);
        if($stmt->fetch()) {
            throw new Exception("Un compte existe déjà avec cet email");
        }
        
        // Créer le compte
        $stmt = $pdo->prepare("INSERT INTO clients (nom, prenom, email, telephone, entreprise, adresse, ville, code_postal, password, rgpd_consent) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
        $stmt->execute([
            $nom,
            $prenom,
            $email,
            $telephone,
            $entreprise,
            $adresse,
            $ville,
            $code_postal,
            password_hash($password, PASSWORD_DEFAULT)
        ]);
        
        $message = "Compte créé avec succès ! Vous pouvez maintenant vous connecter.";
        $messageType = 'success';
        
    } catch(Exception $e) {
        $message = "Erreur : " . $e->getMessage();
        $messageType = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - TechSolutions</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <div class="header-content">
        <div class="logo">
            <img src="images/logo/logo.png" alt="TechSolutions">
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Accueil</a></li>
                <li><a href="services_public.php">Services</a></li>
                <li><a href="about.php">À Propos</a></li>
                <li><a href="contact.php">Contact</a></li>
                <?php if(isset($_SESSION['client_id'])): ?>
                    <li><a href="client_account.php">Mon Compte</a></li>
                <?php else: ?>
                    <li><a href="client_login.php">Espace Client</a></li>
                <?php endif; ?>
                <li><a href="admin/login.php">Admin</a></li>
            </ul>
        </nav>
    </div>
</header>

<div class="container">
    <h2 class="section-title">Créer un compte client</h2>
    
    <?php if($message): ?>
        <div class="message <?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div>
        <?php if($messageType === 'success'): ?>
            <p style="text-align:center;"><a href="client_login.php" class="btn">Se connecter</a></p>
        <?php endif; ?>
    <?php endif; ?>
    
    <div class="content-box" style="max-width:700px;margin:0 auto;">
        <form method="POST">
            <div class="form-group">
                <label>Nom *</label>
                <input type="text" name="nom" required>
            </div>
            
            <div class="form-group">
                <label>Prénom *</label>
                <input type="text" name="prenom" required>
            </div>
            
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" required>
            </div>
            
            <div class="form-group">
                <label>Téléphone</label>
                <input type="tel" name="telephone">
            </div>
            
            <div class="form-group">
                <label>Entreprise</label>
                <input type="text" name="entreprise">
            </div>
            
            <div class="form-group">
                <label>Adresse</label>
                <textarea name="adresse" rows="3"></textarea>
            </div>
            
            <div class="form-group">
                <label>Ville</label>
                <input type="text" name="ville">
            </div>
            
            <div class="form-group">
                <label>Code Postal</label>
                <input type="text" name="code_postal">
            </div>
            
            <div class="form-group">
                <label>Mot de passe *</label>
                <input type="password" name="password" required minlength="6">
                <small>Minimum 6 caractères</small>
            </div>
            
            <div class="form-group">
                <label>Confirmer le mot de passe *</label>
                <input type="password" name="confirm_password" required>
            </div>
            
            <div class="form-group">
                <label style="display:flex;align-items:start;gap:0.5rem;">
                    <input type="checkbox" name="rgpd_consent" required style="margin-top:0.3rem;">
                    <span>J'accepte la politique de confidentialité et le traitement de mes données personnelles conformément au RGPD. Je comprends que je peux à tout moment modifier ou supprimer mes données depuis mon espace client. *</span>
                </label>
            </div>
            
            <button type="submit" name="register" class="btn">Créer mon compte</button>
            
            <p style="text-align:center;margin-top:1rem;">
                Déjà un compte ? <a href="client_login.php">Se connecter</a>
            </p>
        </form>
    </div>
</div>

<footer>
    <p>&copy; 2025 TechSolutions - Tous droits réservés</p>
    <p style="font-size:0.9em;color:#0066CC;margin-top:0.5rem;">
        Site web développé par <strong>Lumni</strong> - Digital Solutions Provider
    </p>
    <p style="font-size:0.85em;margin-top:0.5rem;">
        <a href="mentions_legales.php" style="color:#666;margin:0 1rem;">Mentions légales</a>
        <a href="politique_confidentialite.php" style="color:#666;margin:0 1rem;">Politique de confidentialité</a>
    </p>
</footer>
</body>
</html>
